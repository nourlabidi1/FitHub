// services/planningService.js

const Planning = require('../models/planning');



const getPlanningByCoach = async (nomCoach) => {
  try {
    // Utilisation de findOne pour récupérer un seul planning correspondant au nom du coach
    const planning = await Planning.find({ nom_coach: nomCoach });
    if (!planning) {
      throw new Error('Aucun planning trouvé pour ce coach.');
    }
    return planning;
  } catch (err) {
    throw new Error(err.message);
  }
};

const getPlanningByActivity = async (nomact) => {
  try {
    // Utilisation de findOne pour récupérer un seul planning correspondant au nom du coach
    const planning = await Planning.find({ id_activite: nomact });
    if (!planning) {
      throw new Error('Aucun planning trouvé pour cette activité.');
    }
    return planning;
  } catch (err) {
    throw new Error(err.message);
  }
};

  const addPlanning = async (planning) => {
    try {
      const newPlanning = new Planning(planning);
      return await newPlanning.save();
    } catch (error) {
      throw error;
    }
  };
  


module.exports = {
  addPlanning,
  getPlanningByCoach,
  getPlanningByActivity
}
