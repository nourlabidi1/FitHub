// routers/planningRouter.js
const express = require('express');
const router = express.Router();
const planningController = require('../controllers/planningController');

// Route pour récupérer le planning d'un coach ou d'une activité
router.get('/:coachName', planningController.getPlanningByCoach);
router.get('/activite/:activityName', planningController.getPlanningByActivity);
router.post('/', planningController.addPlanning);
module.exports = router;
