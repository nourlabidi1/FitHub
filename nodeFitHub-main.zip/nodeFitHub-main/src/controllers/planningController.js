// controllers/planningController.js
const planningService = require('../services/planningService');

const addPlanning = async (req, res) => {
  const planning = req.body;
  //console.log("Add activity :", activityData)
  try {
    const newPlanning = await planningService.addPlanning(planning);
    res.status(200).json({ success: true, data: newPlanning, message: 'Planning added successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, message: 'Failed to add planning' });
  }
};
const getPlanningByCoach = async (req, res) => {
  const nomCoach = req.params.coachName; // Récupère le paramètre nom du coach depuis l'URL
  try {
    const planning = await planningService.getPlanningByCoach(nomCoach);
    res.status(200).json(planning);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getPlanningByActivity = async (req, res) => {
  const nomactivity = req.params.activityName; // Récupère le paramètre nom du l'activité depuis l'URL
  try {
    const planning = await planningService.getPlanningByActivity(nomactivity);
    res.status(200).json(planning);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  addPlanning,
  getPlanningByCoach,
  getPlanningByActivity
}
