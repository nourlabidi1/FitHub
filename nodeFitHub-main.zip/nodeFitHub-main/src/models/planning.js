// models/planning.js
const { required } = require('joi');
const mongoose = require('mongoose');

const planningSchema = new mongoose.Schema({
  id_activite: { type: String,
  required: true },
  nom_coach: {
    type :String,
    required :true
  },

  date_debut: {
    type: Date,
    required :true
  },

  date_fin: {
    type: Date,
    required :true
  },
  description :{
    type:String,
    required :false
  }
});

const Planning = mongoose.model('Planning', planningSchema);

module.exports = Planning;
